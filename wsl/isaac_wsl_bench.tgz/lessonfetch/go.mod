module lessonfetch

go 1.25.0
