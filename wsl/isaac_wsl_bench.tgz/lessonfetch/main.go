package main

// lessonfetch — the study road helper: the SAME official client
// flow as the bootdev CLI (their refresh + their endpoint, the
// owner token), printing the raw lesson JSON so the harness can
// read the spec (and the Readme, if the API sends one).

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
)

func cfg(key string) string {
	b, _ := os.ReadFile(os.Getenv("HOME") + "/.bootdev.yaml")
	for _, ln := range strings.Split(string(b), "\n") {
		if strings.HasPrefix(ln, key+":") {
			return strings.TrimSpace(strings.TrimPrefix(ln, key+":"))
		}
	}
	return ""
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: lessonfetch <lesson-uuid>")
		os.Exit(1)
	}
	api := cfg("api_url")
	// refresh, exactly as their client does
	r, _ := http.NewRequest("POST", api+"/v1/auth/refresh",
		bytes.NewBuffer([]byte{}))
	r.Header.Add("X-Refresh-Token", cfg("refresh_token"))
	resp, err := http.DefaultClient.Do(r)
	if err != nil || resp.StatusCode != 200 {
		fmt.Fprintln(os.Stderr, "refresh failed")
		os.Exit(1)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	tok := ""
	for _, part := range strings.Split(string(body), "\"") {
		if strings.HasPrefix(part, "eyJ") && tok == "" {
			tok = part
		}
	}
	req, _ := http.NewRequest("GET", api+v1path(os.Args[1]), nil)
	req.Header.Add("Authorization", "Bearer "+tok)
	resp2, err := http.DefaultClient.Do(req)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out, _ := io.ReadAll(resp2.Body)
	fmt.Println(string(out))
}

func v1path(arg string) string {
	if strings.HasPrefix(arg, "/") {
		return arg
	}
	return "/v1/lessons/" + arg
}
