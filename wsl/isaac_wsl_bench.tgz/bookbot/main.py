import sys
from stats import count_words, count_chars, chars_dict_to_sorted_list

def get_book_text(filepath):
    with open(filepath) as f:
        file_contents = f.read()
    return file_contents

def print_report(path, num_words, sorted_chars):
    print('============ BOOKBOT ============')
    print(f'Analyzing book found at {path}...')
    print('----------- Word Count ----------')
    print(f'Found {num_words} total words')
    print('--------- Character Count -------')
    for pair in sorted_chars:
        if pair[0].isalpha():
            print(f'{pair[0]}: {pair[1]}')
    print('============= END ===============')

def main():
    if len(sys.argv) < 2:
        print('Usage: python3 main.py <path_to_book>')
        sys.exit(1)
    path = sys.argv[1]
    v0 = get_book_text(path)
    v1 = count_words(v0)
    v2 = count_chars(v0)
    v3 = chars_dict_to_sorted_list(v2)
    print_report(path, v1, v3)

main()
