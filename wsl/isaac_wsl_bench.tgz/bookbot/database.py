def count_words(text):
    parts = text.split()
    n = len(parts)
    return n

def count_words(text):
    parts = text.split()
    n = len(parts)
    return n
