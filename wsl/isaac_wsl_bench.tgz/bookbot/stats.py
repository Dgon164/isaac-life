def count_words(text):
    parts = text.split()
    n = len(parts)
    return n

def count_chars(text):
    s = text.lower()
    d = dict()
    for c in s:
        if c not in d:
            d[c] = 1
        else:
            d[c] += 1
    return d

def sort_on(pair):
    return pair[1]

def chars_dict_to_sorted_list(d):
    lst = []
    for c in d:
        lst.append((c, d[c]))
    return sorted(lst, reverse=True, key=sort_on)
